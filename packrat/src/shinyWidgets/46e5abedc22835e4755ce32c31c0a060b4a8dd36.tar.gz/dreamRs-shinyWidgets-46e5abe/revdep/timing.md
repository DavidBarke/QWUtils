# Check times

|   |package            |version | check_time|
|:--|:------------------|:-------|----------:|
|4  |getTBinR           |0.5.5   |      158.1|
|7  |MtreeRing          |1.1     |       70.6|
|8  |rpostgisLT         |0.6.0   |       68.1|
|3  |esquisse           |0.1.6   |         60|
|10 |visNetwork         |2.0.4   |       52.1|
|2  |dplyrAssist        |0.1.0   |       50.2|
|5  |ggplotAssist       |0.1.3   |       44.1|
|6  |gimmeTools         |0.1     |         36|
|1  |bs4Dash            |0.2.0   |       31.4|
|9  |shinydashboardPlus |0.6.0   |       28.8|


